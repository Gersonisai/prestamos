import React from 'react'
import Loans from './loans'
export default function App(){ return <Loans/> }
